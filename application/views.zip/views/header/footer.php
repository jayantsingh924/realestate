 
  <!--/ Footer End /-->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <div id="preloader"></div>

  <!-- JavaScript Libraries -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <!-- <script src="<?php echo base_url();?>assest/lib/jquery/jquery.min.js"></script> -->
  <script src="<?php echo base_url();?>assest/lib/jquery/jquery-migrate.min.js"></script>
  <script src="<?php echo base_url();?>assest/lib/popper/popper.min.js"></script>
  <script src="<?php echo base_url();?>assest/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>assest/lib/easing/easing.min.js"></script>
  <script src="<?php echo base_url();?>assest/lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="<?php echo base_url();?>assest/lib/scrollreveal/scrollreveal.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="<?php echo base_url();?>assest/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo base_url();?>assest/js/main.js"></script>

</body>
</html>